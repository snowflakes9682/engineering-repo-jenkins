#!/bin/bash
STRIKE_LINK=https://api.us-2.crowdstrike.com
CLIENT_ID="{{ CLIENT_USER_ID }}"
CLIENT_SECRET="{{ CLIENT_SECRET_ID }}"
VERSION="6.44.14107"

# oauth key provides key credential for crowdstrike api
OAUTH_KEY=`curl --request POST --url ${STRIKE_LINK}/oauth2/token --header 'Accept: application/json' --header 'Content-Type: application/x-www-form-urlencoded' --data client_id=$CLIENT_ID --data client_secret=$CLIENT_SECRET 2>/dev/null|grep access_token|cut -d\" -f4`
if [[ -z $OAUTH_KEY ]];then
	echo "INSTALLATION FAILED. Authorized account did not found. Exited."
else
    #this extracts the sensor version to be installed on the agent machine
	AGENT_ID=`curl --request GET --url "${STRIKE_LINK}/sensors/combined/installers/v1?offset=0&limit=1&filter=os%3A%22Ubuntu%22&filter=version%3A%22${VERSION}%22&filter" --header 'Accept: application/json' --header "Authorization: Bearer ${OAUTH_KEY}" 2>/dev/null|grep sha256|cut -d\" -f4`
	if [[ -z $AGENT_ID ]];then
		echo "INSTALLATION FAILED. No installer found for the requested version. Exited."
    else    
		#this identifies the agent CCID that will use to register the agent machine to crowdstrike
        AGENT_CC=`curl --request GET --url "${STRIKE_LINK}/sensors/queries/installers/ccid/v1" --header 'Accept: application/json' --header "Authorization: Bearer ${OAUTH_KEY}" 2>/dev/null|grep -A1 resources|grep -v resources|cut -d\" -f2`
	 	if [[ -z $AGENT_CC ]];then
	 		echo "INSTALLATION FAILED. No Crowdstrike ID found to validate sensor on the machine. Exited."
        else
            ###downloads the agent sensor installer 
			curl --request GET --url "${STRIKE_LINK}/sensors/entities/download-installer/v1?id=${AGENT_ID}" --header 'Accept: application/json' --header "Authorization: Bearer ${OAUTH_KEY}" --output /tmp/ubuntu_falcon_installer.deb
			if [[ `ls -l /tmp/ubuntu_falcon_installer.deb 2>/dev/null` == "" ]];then
			    echo "INSTALLATION FAILED. Missing installer. Exited."
            else
                ###register agent machine to crowdstrike
                sudo dpkg -i /tmp/ubuntu_falcon_installer.deb;sudo /opt/CrowdStrike/falconctl -s --cid=${AGENT_CC}; sudo systemctl restart falcon-sensor.service
            fi
        fi
    fi
fi