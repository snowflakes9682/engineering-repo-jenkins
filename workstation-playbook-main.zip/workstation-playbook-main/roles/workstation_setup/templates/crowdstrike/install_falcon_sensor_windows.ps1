$CLIENT_ID="{{ CLIENT_USER_ID }}"
$CLIENT_SECRET="{{ CLIENT_SECRET_ID }}"
$VERSION="6.44.15803"

$OAUTH_TOKEN=(curl.exe -s -X POST --url https://api.us-2.crowdstrike.com/oauth2/token --header 'Accept: application/json' --header 'Content-Type: application/x-www-form-urlencoded' --data client_id=$CLIENT_ID --data client_secret=$CLIENT_SECRET|Where-Object{$_ -match "access_token"}).split('"')[3]
if  ([string]::IsNullOrEmpty($OAUTH_TOKEN)) { 
		"INSTALLATION FAILED. Authorized account did not found. Exited."
		Exit
} else {
		$AGENT_ID=(curl.exe -s -X GET --url "https://api.us-2.crowdstrike.com/sensors/combined/installers/v1?offset=0&limit=1&filter=os%3A%22Windows%22&filter=version%3A%22$($VERSION)%22&filter" --header "Accept: application/json" --header "Authorization: Bearer $OAUTH_TOKEN"|Where-Object{$_ -match "sha256"}).split('"')[3]
		if  ([string]::IsNullOrEmpty($AGENT_ID)) { 
				"INSTALLATION FAILED. No installer found for the requested version. Exited."
				Exit
		} else {
				$AGENT_CC=(curl.exe -s -X GET --url "https://api.us-2.crowdstrike.com/sensors/queries/installers/ccid/v1" --header 'Accept: application/json' --header "Authorization: Bearer $OAUTH_TOKEN"|Select-String "resources" -Context 0,1).context.postcontext
				$AGENT_CC=$AGENT_CC.split('"')[1]
				if  ([string]::IsNullOrEmpty($AGENT_CC)) {
						echo "INSTALLATION FAILED. No Crowdstrike ID found to validate sensor on the machine. Exited."
						Exit
				} else {
						 curl.exe -s -X GET --url "https://api.us-2.crowdstrike.com/sensors/entities/download-installer/v1?id=$($AGENT_ID)" --header 'Accept: application/json' --header "Authorization: Bearer $OAUTH_TOKEN" --output C:\crowdstrike_temp\windows_agent_falcon_installer.exe
						 & C:\crowdstrike_temp\windows_agent_falcon_installer.exe /install /quiet /norestart CID=$AGENT_CC
				}
		}
}