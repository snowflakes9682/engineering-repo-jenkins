#!/bin/bash
# Managed by https://github.com/kjt01/workstation-playbook

chromeversion=`sshpass -p '{{ user_password }}' ssh -o "StrictHostKeyChecking=no" {{ user_name }}@10.111.33.154 "google-chrome --version"`

if [[ `echo $chromeversion|awk '{print $3}'|cut -d\. -f1` -eq 94 ]];then
  echo Google Chrome Version at $chromeversion
else
  exit 1
fi