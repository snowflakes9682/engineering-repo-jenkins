#!/bin/bash

xset s off    # This turns off the "screensaver" feature (not actually a screensaver, just an annoying power saving feature.)
xset -dpms    # Turns off dpms (desktop power management system -- also annoying)

while true; do
    gsettings set org.gnome.desktop.screensaver picture-uri /usr/share/backgrounds/Wallpaper/"$(ls /usr/share/backgrounds/Wallpaper/ | sort -R | tail -n 1)"
    sleep 60    # This is the amount of time in seconds to wait before changing
done